CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE IF NOT EXISTS stations (
  id BIGSERIAL PRIMARY KEY,
  station_code VARCHAR(40) UNIQUE NOT NULL,
  station_name VARCHAR(160) NOT NULL,
  subdivision VARCHAR(120) NOT NULL,
  boundary GEOMETRY(MULTIPOLYGON, 4326),
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS incidents (
  id BIGSERIAL PRIMARY KEY,
  internal_ref VARCHAR(80) UNIQUE NOT NULL,
  source_ref VARCHAR(160),
  category VARCHAR(100) NOT NULL DEFAULT 'Unclassified',
  station_id BIGINT REFERENCES stations(id),
  occurred_at TIMESTAMPTZ,
  status VARCHAR(50) NOT NULL DEFAULT 'Received',
  location GEOMETRY(POINT, 4326),
  provenance VARCHAR(80) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS incidents_location_gix ON incidents USING GIST(location);
CREATE INDEX IF NOT EXISTS incidents_occurred_at_idx ON incidents(occurred_at);
CREATE INDEX IF NOT EXISTS incidents_station_idx ON incidents(station_id);

CREATE TABLE IF NOT EXISTS incident_history (
  id BIGSERIAL PRIMARY KEY,
  incident_id BIGINT NOT NULL REFERENCES incidents(id),
  actor_id VARCHAR(120) NOT NULL,
  change_summary TEXT NOT NULL,
  previous_values JSONB,
  new_values JSONB,
  changed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS patrol_assignments (
  id BIGSERIAL PRIMARY KEY,
  station_id BIGINT REFERENCES stations(id),
  title VARCHAR(160) NOT NULL,
  time_window VARCHAR(120),
  objective TEXT,
  status VARCHAR(50) NOT NULL DEFAULT 'Planned',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_events (
  id BIGSERIAL PRIMARY KEY,
  actor_id VARCHAR(120) NOT NULL,
  action VARCHAR(100) NOT NULL,
  object_type VARCHAR(100) NOT NULL,
  object_id VARCHAR(120),
  reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
