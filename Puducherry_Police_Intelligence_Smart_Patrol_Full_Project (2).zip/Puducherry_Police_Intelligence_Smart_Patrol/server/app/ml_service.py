"""Aggregate volume forecast starter; not an individual risk model."""
from collections import Counter
from datetime import datetime, timezone
from sqlalchemy import select
from .models import Incident

def aggregate_forecast(db) -> dict:
    rows = db.scalars(select(Incident)).all()
    dated = [r for r in rows if r.date is not None]
    if len(dated) < 7:
        return {"status": "insufficient_history", "records_with_dates": len(dated),
                "message": "Load a sufficient amount of authorised, quality-checked historical data before evaluating forecasts."}
    counts = Counter(r.date.date().isoformat() for r in dated)
    vals = list(counts.values())
    baseline = sum(vals) / len(vals)
    return {"status": "baseline_only", "method": "mean records per represented date",
            "represented_dates": len(vals), "mean_records_per_date": round(baseline, 2),
            "message": "This is a simple baseline, not a validated operational forecast. Evaluate against later held-out dates."}
