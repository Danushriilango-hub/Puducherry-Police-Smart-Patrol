from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict

class IncidentCreate(BaseModel):
    ref: str = Field(min_length=1, max_length=80)
    category: str = Field(default="Unclassified", max_length=100)
    station: str = Field(default="Unassigned", max_length=120)
    date: datetime | None = None
    status: str = Field(default="Received", max_length=50)
    lat: float | None = Field(default=None, ge=-90, le=90)
    lon: float | None = Field(default=None, ge=-180, le=180)
    source_ref: str | None = Field(default=None, max_length=160)
    severity: str = Field(default="Not classified", max_length=50)
    provenance: str = Field(default="illustrative", max_length=80)

class IncidentOut(IncidentCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    created_at: datetime
    updated_at: datetime

class IncidentList(BaseModel):
    items: list[IncidentOut]
    total: int

class AssistantQuery(BaseModel):
    question: str = Field(min_length=1, max_length=500)

class PatrolCreate(BaseModel):
    title: str = Field(min_length=1, max_length=160)
    station: str = Field(min_length=1, max_length=120)
    time_window: str = Field(default="", max_length=120)
    objective: str = Field(default="", max_length=1000)
    status: str = Field(default="Planned", max_length=50)
