import os
from datetime import datetime, timezone
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from .db import Base, engine, get_db
from .models import Incident, PatrolAssignment
from .schemas import IncidentCreate, IncidentOut, IncidentList, AssistantQuery, PatrolCreate
from .ai_service import answer_question
from .ml_service import aggregate_forecast

Base.metadata.create_all(bind=engine)
app = FastAPI(title="Puducherry Police Intelligence & Smart Patrol API", version="0.1.0")

origins = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://127.0.0.1:5500,http://localhost:5500").split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False,
                   allow_methods=["GET", "POST", "PATCH", "DELETE"], allow_headers=["*"])

@app.get("/health")
def health():
    return {"status": "ok", "service": "smart-patrol-api", "time_utc": datetime.now(timezone.utc).isoformat()}

@app.get("/stations")
def stations():
    # Replace with an approved official station directory before operational use.
    return {"items": [
        {"subdivision": "Puducherry Region", "station": "Central Station", "provenance": "illustrative"},
        {"subdivision": "Puducherry Region", "station": "North Station", "provenance": "illustrative"},
        {"subdivision": "Puducherry Region", "station": "East Station", "provenance": "illustrative"},
        {"subdivision": "Puducherry Region", "station": "South Station", "provenance": "illustrative"},
        {"subdivision": "Karaikal Region", "station": "Karaikal Station", "provenance": "illustrative"},
        {"subdivision": "Mahe Region", "station": "Mahe Station", "provenance": "illustrative"},
        {"subdivision": "Yanam Region", "station": "Yanam Station", "provenance": "illustrative"}
    ]}

@app.get("/incidents", response_model=IncidentList)
def list_incidents(limit: int = 500, offset: int = 0, db: Session = Depends(get_db)):
    limit = max(1, min(limit, 1000))
    total = db.scalar(select(func.count()).select_from(Incident)) or 0
    items = db.scalars(select(Incident).order_by(Incident.id.desc()).offset(offset).limit(limit)).all()
    return {"items": items, "total": total}

@app.post("/incidents", response_model=IncidentOut, status_code=201)
def create_incident(payload: IncidentCreate, db: Session = Depends(get_db)):
    if db.scalar(select(Incident).where(Incident.ref == payload.ref)):
        raise HTTPException(status_code=409, detail="Reference already exists")
    item = Incident(**payload.model_dump())
    db.add(item)
    db.commit()
    db.refresh(item)
    return item

@app.patch("/incidents/{incident_id}", response_model=IncidentOut)
def update_incident(incident_id: int, payload: IncidentCreate, db: Session = Depends(get_db)):
    item = db.get(Incident, incident_id)
    if not item:
        raise HTTPException(status_code=404, detail="Record not found")
    if payload.ref != item.ref and db.scalar(select(Incident).where(Incident.ref == payload.ref)):
        raise HTTPException(status_code=409, detail="Reference already exists")
    for key, value in payload.model_dump().items():
        setattr(item, key, value)
    item.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(item)
    return item

@app.delete("/incidents/{incident_id}")
def delete_incident(incident_id: int, db: Session = Depends(get_db)):
    item = db.get(Incident, incident_id)
    if not item:
        raise HTTPException(status_code=404, detail="Record not found")
    db.delete(item)
    db.commit()
    return {"deleted": True, "id": incident_id}

@app.post("/assistant/query")
def assistant_query(payload: AssistantQuery, db: Session = Depends(get_db)):
    return answer_question(payload.question, db)

@app.get("/analytics/summary")
def analytics_summary(db: Session = Depends(get_db)):
    total = db.scalar(select(func.count()).select_from(Incident)) or 0
    rows = db.execute(select(Incident.category, func.count()).group_by(Incident.category)).all()
    return {"total": total, "categories": [{"category": c or "Unclassified", "count": n} for c, n in rows]}

@app.get("/analytics/forecast")
def forecast(db: Session = Depends(get_db)):
    return aggregate_forecast(db)

@app.get("/patrols")
def list_patrols(db: Session = Depends(get_db)):
    rows = db.scalars(select(PatrolAssignment).order_by(PatrolAssignment.id.desc())).all()
    return {"items": [{"id": x.id, "title": x.title, "station": x.station, "time_window": x.time_window,
                       "objective": x.objective, "status": x.status} for x in rows]}

@app.post("/patrols", status_code=201)
def create_patrol(payload: PatrolCreate, db: Session = Depends(get_db)):
    allowed = {"Planned", "Assigned", "Started", "Completed"}
    if payload.status not in allowed:
        raise HTTPException(status_code=422, detail="Unsupported status")
    item = PatrolAssignment(title=payload.title, station=payload.station, time_window=payload.time_window,
                            objective=payload.objective, status=payload.status)
    db.add(item)
    db.commit()
    db.refresh(item)
    return {"id": item.id, "title": item.title, "station": item.station, "time_window": item.time_window,
            "objective": item.objective, "status": item.status}
