"""Restricted assistant. It never executes arbitrary model-generated SQL."""
from collections import Counter
from sqlalchemy import select
from .models import Incident

ALLOWED_INTENTS = ("category", "station", "quality", "total")

def answer_question(question: str, db) -> dict:
    q = question.casefold()
    rows = db.scalars(select(Incident)).all()
    if any(w in q for w in ("category", "categories", "type")):
        counts = Counter((r.category or "Unclassified") for r in rows)
        return {"answer": "Aggregate records by category.", "intent": "category_counts",
                "total": len(rows), "results": [{"label": k, "count": v} for k, v in sorted(counts.items())]}
    if "station" in q:
        counts = Counter((r.station or "Unassigned") for r in rows)
        return {"answer": "Aggregate records by station.", "intent": "station_counts",
                "total": len(rows), "results": [{"label": k, "count": v} for k, v in sorted(counts.items())]}
    if any(w in q for w in ("missing", "quality", "incomplete", "coordinates")):
        missing_coords = sum(r.lat is None or r.lon is None for r in rows)
        missing_source = sum(not r.source_ref for r in rows)
        return {"answer": "Data-quality summary for the records visible to this service.",
                "intent": "data_quality", "total": len(rows),
                "missing_coordinates": missing_coords, "missing_source_reference": missing_source}
    if any(w in q for w in ("how many", "total", "count", "number")):
        return {"answer": "Total records in the current service scope.", "intent": "total_count", "total": len(rows)}
    return {"answer": "I can answer aggregate questions about totals, categories, stations, and data quality. Try asking for a category count or missing-coordinate summary.",
            "intent": "unsupported", "total": len(rows)}
