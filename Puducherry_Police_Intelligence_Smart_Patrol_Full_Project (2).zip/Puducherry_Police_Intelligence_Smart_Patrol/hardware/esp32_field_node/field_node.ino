/*
  ESP32 field-node starter.
  This version reports local sensor/device status to Serial only.
  Network transmission should be added only after a signed, authenticated
  backend ingestion endpoint and authorised deployment plan exist.
*/
#include <Arduino.h>

void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.println("Field node started");
  Serial.println("Network reporting is not enabled in this starter.");
}

void loop() {
  Serial.printf("device_status=ok uptime_ms=%lu\n", millis());
  delay(5000);
}
