# Optional ESP32 Field Node

Purpose: a small engineering add-on for recording an authorised checkpoint visit or sending non-sensitive environmental/device-health telemetry to a backend. It is not required for the core application.

Suggested components:
- ESP32 development board
- NEO-6M GPS module, if a lawful and approved location use case exists
- BH1750 light sensor, only where ambient light is relevant
- Optional RFID reader for controlled checkpoint tokens; do not store personal identity data on RFID cards

Before connecting hardware to any operational environment, get approval for installation, data fields, network access, retention, and device security. Keep firmware credentials out of public repositories. The current backend does not expose a hardware ingestion endpoint; implement and test a signed device endpoint before enabling network transmission.
