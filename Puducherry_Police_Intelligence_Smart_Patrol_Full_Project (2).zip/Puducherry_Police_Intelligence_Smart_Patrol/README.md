# Puducherry Police Intelligence & Smart Patrol System

A full-stack starter project containing:
- Web operations dashboard
- Flutter Android application source
- FastAPI backend
- PostgreSQL/PostGIS database schema and Docker Compose setup
- Rule-based Ask the Map assistant with safe, allow-listed aggregate queries
- Aggregate time-series forecasting starter
- Patrol assignment and route-planning interfaces
- Optional ESP32 field-node starter
- Windows setup instructions and architecture notes

## Data source status

The project starts with clearly identified illustrative records. It does not connect to the department's internal FIR system by default. Use only an authorised API or an approved export supplied by the data owner. Do not attempt to bypass portal authentication or access controls. Configure the official connector only after the department has approved the integration and data fields.

## Project layout

- `web/index.html` — browser dashboard
- `server/app/main.py` — FastAPI endpoints
- `server/app/ai_service.py` — restricted natural-language query helper
- `server/app/ml_service.py` — aggregate forecast starter
- `server/sql/schema.sql` — PostgreSQL/PostGIS schema
- `server/docker-compose.yml` — local PostgreSQL/PostGIS container
- `mobile/` — Flutter Android application starter
- `hardware/esp32_field_node/` — optional ESP32 sensor/GPS node sketch
- `docs/` — API, security, data integration, and rollout notes

## Windows quick start: backend

Install Python 3.11 or later and Docker Desktop.

Open PowerShell in this folder:

```powershell
cd server
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
docker compose up -d db
uvicorn app.main:app --reload
```

Open:
- API status: `http://127.0.0.1:8000/health`
- API documentation: `http://127.0.0.1:8000/docs`

If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope Process Bypass` in that same terminal, then activate again. You can also run `.venv\Scripts\python.exe -m pip install -r requirements.txt` without activating the environment.

The backend can run with a local SQLite database if PostgreSQL is not configured. PostgreSQL/PostGIS is the intended shared deployment database.

## Windows quick start: web dashboard

Open `web/index.html` in Edge or Chrome. The dashboard can run in local-only mode. To connect it to the backend, set the API URL in the dashboard's connection panel to `http://127.0.0.1:8000` and use the backend endpoints.

Browser restrictions can affect requests from a local file. If API requests fail, serve the web folder locally:

```powershell
cd web
py -m http.server 5500
```

Then open `http://127.0.0.1:5500`.

## Windows quick start: Android app

Install Flutter SDK, Android Studio, and the Android SDK. In PowerShell:

```powershell
cd mobile
flutter pub get
flutter run
```

For the Android emulator, the host computer is usually reachable at `http://10.0.2.2:8000`. For a physical phone, configure the backend URL to the host's reachable LAN address on a trusted network, and configure firewall rules appropriately.

Build an APK:

```powershell
flutter build apk
```

The APK is usually created at `mobile/build/app/outputs/flutter-apk/app-release.apk` for a release build. Run `flutter build apk --release` to request a release build.

## AI and ML

- Ask the Map only supports allow-listed aggregate queries. It does not execute arbitrary SQL.
- The ML endpoint is a simple aggregate forecast starter. It needs enough authorised, quality-checked historical data and evaluation before operational use.
- Optional LLM integration is deliberately not hard-coded to a provider. Add an approved provider and server-side secret only after data-governance review. Never embed API keys in Flutter or browser code.

## Before operational use

Configure production authentication, HTTPS, role-based permissions, audit logging, backup and recovery, data-retention rules, monitoring, security testing, and departmental approval. The included authentication scaffold is not a complete production identity system.
