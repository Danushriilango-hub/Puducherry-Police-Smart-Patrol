# API reference

Start the API with `uvicorn app.main:app --reload` from the `server` folder.

| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | Health and service timestamp |
| GET | `/stations` | Station directory starter |
| GET | `/incidents` | List records with `limit` and `offset` |
| POST | `/incidents` | Create a record |
| PATCH | `/incidents/{id}` | Update a record |
| DELETE | `/incidents/{id}` | Delete a record in the local starter |
| POST | `/assistant/query` | Restricted aggregate question handler |
| GET | `/analytics/summary` | Aggregate summary |
| GET | `/analytics/forecast` | Baseline aggregate forecast |
| GET | `/patrols` | List patrol assignments |
| POST | `/patrols` | Create a patrol assignment |

The included API is a development scaffold. Before shared or operational use, add identity integration, station-scoped authorisation, immutable audit logging, record history, rate limits, security headers, HTTPS, monitoring, and a review/approval workflow. In particular, protect update and delete operations and do not expose the service publicly as configured here.
