# Architecture

```text
Flutter Android app ─┐
                     ├── HTTPS API ── identity and permissions
Web dashboard ───────┘        │
                              ├── PostgreSQL + PostGIS
                              ├── approved data ingestion adapter
                              ├── aggregate analytics / ML service
                              ├── restricted Ask the Map assistant
                              ├── patrol assignment service
                              └── audit and monitoring
```

Start with one central backend and station-scoped access. Add station-side offline caches only if connectivity requirements justify them. If independent station servers are mandated, design signed synchronisation, conflict resolution, retries, idempotency, and central audit logging before deployment.
