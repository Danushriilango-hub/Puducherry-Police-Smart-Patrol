# ML plan

## First task
Forecast aggregate record volume by time period and authorised geographic unit.

## Baseline
Use a moving average or mean count from comparable periods.

## Data preparation
- Use approved historical data with stable category and station mappings.
- Create explicit zero-count periods where the source confirms complete coverage.
- Check missing data, duplicate source IDs, timezone consistency, and changes in reporting practice.
- Exclude personal identifiers and free-text narratives unless a specifically approved task requires them.

## Evaluation
- Split chronologically; train on earlier periods and test on later periods.
- Compare against the simple baseline.
- Report MAE and error by period and geographic unit.
- Record training data version, model version, features, evaluation results, and approval.
- Display uncertainty and data freshness.
- Monitor drift and roll back if performance degrades.

Do not use this forecast to label individuals as suspects or autonomously allocate enforcement against people or communities.
