# Approved FIR / incident data integration plan

1. Identify the department's authorised data owner and the intended use.
2. Request a documented API, secure scheduled export, or other approved integration.
3. Agree on field definitions, station identifiers, time zone conventions, source references, data classification, and retention.
4. Build a separate ingestion adapter. Never put portal passwords, session cookies, or API secrets in the browser or mobile app.
5. Validate schema, timestamp, source identifier, category, and approved geographic fields.
6. Make imports idempotent so the same source record does not create duplicates.
7. Store source provenance, import time, rejected rows, and corrections.
8. Expose only role-authorised records and aggregate statistics through the API.
9. Display last successful update and connector health.
10. Test with an approved export before enabling scheduled synchronisation.

The public FIR download form is not itself a documented real-time API. Do not automate access by bypassing authentication, captcha, or access controls.
