# Security and governance checklist

- Departmental approval and documented data-owner responsibility.
- Approved purpose, permitted fields, access scope, retention period, and deletion rules.
- Individual identities; MFA for privileged users; session expiry and account revocation.
- Server-side authorisation on every request, including object-level station checks.
- HTTPS in all shared environments; encrypted backups and secrets management.
- Audit logs for access, changes, approvals, exports, and administrative actions.
- Restricted bulk export and download controls.
- Input validation, upload scanning, dependency updates, and security testing.
- Backup restoration tests, incident response plan, monitoring, and alerting.
- LLM data minimisation, restricted tools, prompt-injection testing, and human review.
- ML evaluation on held-out time periods, drift monitoring, error analysis by geography, and a rollback plan.
- No automated individual suspicion scoring or autonomous enforcement decisions.
