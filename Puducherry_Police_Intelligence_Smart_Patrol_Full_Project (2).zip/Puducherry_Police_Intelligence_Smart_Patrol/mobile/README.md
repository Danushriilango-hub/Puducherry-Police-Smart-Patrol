# Android application

## Requirements
- Flutter SDK
- Android Studio and Android SDK
- Android emulator or Android phone

## Run
```powershell
flutter pub get
flutter run
```

The default API URL is `http://10.0.2.2:8000`, suitable for the standard Android emulator when the backend runs on the same computer. Override it with `flutter run --dart-define=API_BASE_URL=http://10.0.2.2:8000`. For a physical phone, use the computer's reachable LAN IP on a trusted network and configure the firewall/server binding accordingly. The starter API does not include a production login system; do not expose it to a public or operational network.

## Internet permission
If missing, add this line above the `<application>` element in `android/app/src/main/AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
```

Plain HTTP is for local development only. For shared deployment, configure HTTPS and update the API URL.

## Build APK
```powershell
flutter build apk --release
```
