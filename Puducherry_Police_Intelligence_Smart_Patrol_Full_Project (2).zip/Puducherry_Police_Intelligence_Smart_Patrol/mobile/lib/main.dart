import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

void main() => runApp(const SmartPatrolApp());

class SmartPatrolApp extends StatelessWidget {
  const SmartPatrolApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Smart Patrol',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff087f8c), brightness: Brightness.dark), useMaterial3: true),
    home: const HomeScreen(),
  );
}

class ApiService {
  // Android emulator: 10.0.2.2 reaches the development host computer.
  // Change this for a secured server or reachable test machine.
  static const baseUrl = String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:8000');
  static Future<Map<String, dynamic>> get(String path) async {
    final response = await http.get(Uri.parse('$baseUrl$path')).timeout(const Duration(seconds: 12));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Server returned ${response.statusCode}');
    }
    return jsonDecode(response.body) as Map<String, dynamic>;
  }
  static Future<Map<String, dynamic>> post(String path, Map<String, dynamic> body) async {
    final response = await http.post(Uri.parse('$baseUrl$path'), headers: {'Content-Type':'application/json'}, body: jsonEncode(body)).timeout(const Duration(seconds: 12));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Server returned ${response.statusCode}: ${response.body}');
    }
    return jsonDecode(response.body) as Map<String, dynamic>;
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selected = 0;
  bool loading = false;
  String error = '';
  List<dynamic> incidents = [];
  List<dynamic> patrols = [];
  final questionController = TextEditingController();
  String answer = 'Ask an aggregate question about categories, stations, totals, or data quality.';
  final patrolTitle = TextEditingController();
  final patrolStation = TextEditingController(text: 'Central Station');
  final patrolObjective = TextEditingController();

  @override void initState() { super.initState(); refresh(); }
  @override void dispose() { questionController.dispose(); patrolTitle.dispose(); patrolStation.dispose(); patrolObjective.dispose(); super.dispose(); }

  Future<void> refresh() async {
    setState(() { loading = true; error = ''; });
    try {
      final results = await Future.wait([ApiService.get('/incidents'), ApiService.get('/patrols')]);
      setState(() { incidents = (results[0]['items'] as List?) ?? []; patrols = (results[1]['items'] as List?) ?? []; });
    } catch (e) { setState(() => error = 'Could not reach the API. Start the backend and check API_BASE_URL. Details: $e'); }
    finally { if (mounted) setState(() => loading = false); }
  }

  Future<void> ask() async {
    try {
      final result = await ApiService.post('/assistant/query', {'question': questionController.text});
      setState(() => answer = const JsonEncoder.withIndent('  ').convert(result));
    } catch (e) { setState(() => answer = 'Assistant service unavailable: $e'); }
  }

  Future<void> createPatrol() async {
    if (patrolTitle.text.trim().isEmpty) { setState(() => error = 'Enter an assignment title.'); return; }
    try {
      await ApiService.post('/patrols', {'title':patrolTitle.text.trim(),'station':patrolStation.text.trim(),'time_window':'Not specified','objective':patrolObjective.text.trim(),'status':'Planned'});
      patrolTitle.clear(); patrolObjective.clear(); await refresh();
    } catch (e) { setState(() => error = 'Could not save assignment: $e'); }
  }

  @override Widget build(BuildContext context) {
    final pages = [
      _overview(), _mapPage(), _recordsPage(), _patrolPage(), _assistantPage(),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Intelligence & Smart Patrol'), actions: [IconButton(onPressed: refresh, icon: const Icon(Icons.refresh), tooltip: 'Refresh data')]),
      body: Column(children: [
        if (error.isNotEmpty) MaterialBanner(content: Text(error), actions: [TextButton(onPressed: () => setState(() => error = ''), child: const Text('Dismiss'))]),
        if (loading) const LinearProgressIndicator(),
        Expanded(child: IndexedStack(index: selected, children: pages)),
      ]),
      bottomNavigationBar: NavigationBar(selectedIndex: selected, onDestinationSelected: (v) => setState(() => selected = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Home'),
        NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'Map'),
        NavigationDestination(icon: Icon(Icons.description_outlined), selectedIcon: Icon(Icons.description), label: 'Records'),
        NavigationDestination(icon: Icon(Icons.route_outlined), selectedIcon: Icon(Icons.route), label: 'Patrols'),
        NavigationDestination(icon: Icon(Icons.psychology_outlined), selectedIcon: Icon(Icons.psychology), label: 'Ask AI'),
      ]),
    );
  }

  Widget _overview() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Operations overview', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    Wrap(spacing: 12, runSpacing: 12, children: [
      _metric('Records', '${incidents.length}', Icons.description),
      _metric('Assignments', '${patrols.length}', Icons.route),
      _metric('Data source', 'API', Icons.cloud_done),
    ]),
    const SizedBox(height: 16),
    Card(child: ListTile(leading: const Icon(Icons.shield_outlined), title: const Text('Secure access'), subtitle: const Text('Connect this client only to an authorised, secured backend.'))),
    Card(child: ListTile(leading: const Icon(Icons.update), title: const Text('Refresh status'), subtitle: Text(loading ? 'Loading…' : error.isEmpty ? 'Last manual refresh completed' : 'Connection needs attention'))),
    const SizedBox(height: 8),
    const Text('Recent records', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
    ...incidents.take(6).map((r) => Card(child: ListTile(title: Text('${r['ref'] ?? 'Record'} · ${r['category'] ?? 'Unclassified'}'), subtitle: Text('${r['station'] ?? 'Unassigned'} · ${r['status'] ?? 'Received'}')))),
  ]);

  Widget _metric(String title, String value, IconData icon) => SizedBox(width: 150, child: Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon), const SizedBox(height: 8), Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), Text(title)]))));

  Widget _mapPage() {
    final markers = incidents.where((r) => r['lat'] != null && r['lon'] != null).map((r) => Marker(
      point: LatLng((r['lat'] as num).toDouble(), (r['lon'] as num).toDouble()), width: 36, height: 36,
      child: Tooltip(message: '${r['category'] ?? ''} · ${r['station'] ?? ''}', child: const Icon(Icons.location_on, color: Colors.tealAccent, size: 32)),
    )).toList();
    return Column(children: [
      const Padding(padding: EdgeInsets.all(12), child: Align(alignment: Alignment.centerLeft, child: Text('Incident map', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)))),
      Expanded(child: FlutterMap(options: const MapOptions(initialCenter: LatLng(11.94, 79.83), initialZoom: 10), children: [
        TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'org.example.puducherry_police_app'),
        MarkerLayer(markers: markers),
      ])),
      const Padding(padding: EdgeInsets.all(8), child: Text('Use approved data and verify map attribution and provider terms before release.', style: TextStyle(fontSize: 12))),
    ]);
  }

  Widget _recordsPage() => ListView(padding: const EdgeInsets.all(12), children: [
    const Text('Authorised records', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    ...incidents.map((r) => Card(child: ExpansionTile(title: Text('${r['ref'] ?? 'Record'} · ${r['category'] ?? 'Unclassified'}'), subtitle: Text('${r['station'] ?? 'Unassigned'} · ${r['status'] ?? 'Received'}'), children: [
      ListTile(title: const Text('Date'), subtitle: Text('${r['date'] ?? 'Not provided'}')),
      ListTile(title: const Text('Source reference'), subtitle: Text('${r['source_ref'] ?? 'Not provided'}')),
    ]))),
  ]);

  Widget _patrolPage() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Patrol assignments', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
    TextField(controller: patrolTitle, decoration: const InputDecoration(labelText: 'Assignment title')),
    TextField(controller: patrolStation, decoration: const InputDecoration(labelText: 'Responsible station')),
    TextField(controller: patrolObjective, decoration: const InputDecoration(labelText: 'Coverage objective')),
    const SizedBox(height: 12),
    FilledButton.icon(onPressed: createPatrol, icon: const Icon(Icons.add), label: const Text('Create assignment')),
    const SizedBox(height: 16),
    ...patrols.map((p) => Card(child: ListTile(leading: const Icon(Icons.route), title: Text('${p['title']}'), subtitle: Text('${p['station']} · ${p['status']}')))),
  ]);

  Widget _assistantPage() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Ask the Map', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    const Text('Ask about aggregate categories, station counts, total records, or data quality.'),
    TextField(controller: questionController, minLines: 2, maxLines: 4, decoration: const InputDecoration(hintText: 'How many records are grouped by category?')),
    const SizedBox(height: 8),
    FilledButton.icon(onPressed: ask, icon: const Icon(Icons.send), label: const Text('Ask')),
    const SizedBox(height: 12),
    Card(child: Padding(padding: const EdgeInsets.all(12), child: SelectableText(answer))),
  ]);
}
